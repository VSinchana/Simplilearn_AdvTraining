package Prog7_2;

@SuppressWarnings("serial")
public class NameNotValidException extends Exception {
	public String validname()
    {
         return ("Name is not Valid...Please Re-Enter the Name");
    }
	
}
