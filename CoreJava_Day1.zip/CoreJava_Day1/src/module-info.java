module CoreJava_Day1 {
}