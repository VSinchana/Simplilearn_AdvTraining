module CoreJava_Day2 {
}