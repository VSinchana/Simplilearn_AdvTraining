package Prog11;

import java.util.Vector;

public class Main {
	static int deno[] = {1, 2, 5, 10, 20, 
		    50, 100, 500, 1000, 2000};
		    static int n = deno.length;
		  
		    static void findMin(int V)
		    {
		      
		        Vector<Integer> ans = new Vector<>();
		  
		         
		        for (int i = n - 1; i >= 0; i--)
		        {
		             
		            while (V >= deno[i]) 
		            {
		                V -= deno[i];
		                ans.add(deno[i]);
		            }
		        }
		  
		         
		        for (int i = 0; i < ans.size(); i++)
		        {
		            System.out.println(" " + ans.elementAt(i));
		        }
		    }
		  
		    
		    public static void main(String[] args) 
		    {
		        int n = 69;
		        System.out.println("Following is minimal number of change for " + n + ": ");
		        findMin(n);
		        
		        int x = 179;
		        System.out.println("Following is minimal number of change for " + x + ": ");
		        findMin(x);
		        
		        int y = 3025;
		        System.out.println("Following is minimal number of change for " + y + ": ");
		        findMin(y);
		    }
	
}
